# 1.1.0（2026-10-23）

对齐上游 dsh-bili-scroll 2.0.4 的平台无关修复：

- 修实机故障：`resolveDsh` 认识桌面版 DeepSeek Harness 自带的 dsh
  （直连 `DeepSeek Harness.exe --expose-internals .../dsh-desktop-host/lib/cli.js`，
  ELECTRON_RUN_AS_NODE、不经 cmd，避开 8191 字符参数上限；`dsh.cmd` 与 npm 全局作兜底；
  PATH 里解析绝对路径、绝不 shell:true 拼提示词 —— 对齐上游安全加固）。
  以前 `'dsh' 不是内部或外部命令`，每一轮 exit 1。
- 修实机故障：DSH 设置视图把 headlessProfile 递成对象 ⇒ `--profile [object Object]`。
  refreshCfg 现在只收原始值（string/number/boolean）。
- 单轮锁 + 子进程登记/清理（上游 2.0.4 体检第 2 条）：同一时间只允许一轮在跑，
  插件卸载时把正在跑的子进程一起收掉。
- `writeJson` 原子写（tmp + rename）：config.json / state.json 不再可能留半截。
- 值班章程升级改**记账制**（上游 M6）：`charter.sha256` 账本 —— 没改过自动升级，
  改过则新版落 `duty.md.new`，不再"一次铺定、永不更新"。

# 1.1.1（2026-10-23，实机验证后）

- MCP 服务脚本改用**桌面版自带真 node** 当解释器
  （`resources/runtime/primary-runtime/dependencies/node/bin/node.exe`，v24）。
  以前写 `process.execPath`，在桌面版里那是 Electron 主程序，跑 .mjs 只在"父进程碰巧继承了
  ELECTRON_RUN_AS_NODE"时才成立；现在显式指定，并在退回主程序时把 ELECTRON_RUN_AS_NODE 写进 overlay env。
- 截帧 seek 不再偶发 `Promise was collected`：promise 挂 window 保活；
  真被回收也退化成"等一会儿直接截"，不丢整帧。
- `tools/mcp-probe.mjs` 的家目录不再写死作者机器路径（读 DOUYIN_HOME / DSH_HOME 兜底）。

# 1.1.2（2026-10-23，实机第二轮）

- 修实机故障：选中的 `dsh.cmd` 路径带空格（`…\DeepSeek Harness\…`），
  node 的 `spawn(shell:true)` **不会给 command 单独加引号**，整串塞进 `cmd /d /s /c "…"`
  后被砍成 `…\DeepSeek` ⇒ "'…\DeepSeek' 不是内部或外部命令"，exit 1。
  现在 shell 候选一律经 `shellCmd()` 补引号（已实测加引号后 `dsh.cmd --help` exit 0）。
- 修根因：直连 CLI 方案被 `existsSync` 误判。**cli.js 在 app.asar 归档内部**，
  普通 fs 的 existsSync 恒 false（只有 Electron 主进程打了 asar 补丁才查得到），
  于是 ② 被跳过、退回 ③。现在改为验证"主程序 + app.asar 归档"存在，
  cli.js 走 `noStatArgs` 免检 ⇒ 优先选 ②（无 cmd、无 8191 字符上限）。
  本机复现确认：选中「② 直连 CLI」，shell=false。
