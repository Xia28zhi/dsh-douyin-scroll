/**
 * dsh-douyin-scroll —— 浏览器半端（**在「设置」里占一页**）
 * ============================================================================
 * ⭐ client bundle **不是 ESM，是自注册脚本**（dsh 的约定）：
 *     window.__ModuleLoader__.load({ id: '<包名>', factory: (require) => ({ inject, apply(ctx) }) })
 * ⭐ 怎么进「设置」（抄 dsh-meme / dsh-bili-scroll）：
 *     slots.inject('settings.section', () => slots.register({ id, order, label }, () => h(Panel)))
 *   ⇒ **别自己糊一个全屏 overlay**，跟别的插件长得不一样主人一眼就看出来了。
 *
 * 这一页的规矩（跟参考项目一致）：
 *   · 账号绑定**就在设置页里**（点一下开窗口，里面扫码）；
 *   · 会动账号的（自动收藏 / 评论 @ 你）、要花钱的（视觉模型）**默认关**；
 *   · 每个改动立刻存，并提供「测一下」直接回答"能不能用"。
 * ============================================================================
 */
window.__ModuleLoader__.load({
  id: 'dsh-douyin-scroll',
  factory: (require) => {
    const React = require('react')
    const h = React.createElement
    const useState = React.useState
    const useEffect = React.useEffect
    const useCallback = React.useCallback

    const API = '/api/douyin-duty'

    const asJson = async (res) => {
      if (res.ok) return res.json()
      const why = res.status === 401 ? '（未登录 / 没权限）' : res.status === 403 ? '（被宿主拦了）' : ''
      throw new Error('HTTP ' + res.status + why)
    }
    const jget = async (p) => asJson(await fetch(API + p, { credentials: 'same-origin' }))
    // ⭐ 加固后：改状态的 POST 必须带 x-douyin-token（同源 GET /token 换，缓存住）
    let API_TOKEN = ''
    const ensureToken = async () => {
      if (API_TOKEN) return API_TOKEN
      try { API_TOKEN = String((await jget('/token')).token || '') } catch { API_TOKEN = '' }
      return API_TOKEN
    }
    const jpost = async (p, body) => asJson(await fetch(API + p, {
      method: 'POST', credentials: 'same-origin',
      headers: { 'content-type': 'application/json', 'x-douyin-token': await ensureToken() },
      body: JSON.stringify(body || {}),
    }))

    const CSS = `
[data-dd-page]{display:flex;flex-direction:column;gap:18px;padding:2px 2px 8px;max-width:660px;}
[data-dd-sec]{display:flex;flex-direction:column;gap:8px;}
[data-dd-h]{font-size:11px;font-weight:600;letter-spacing:.04em;color:var(--dsw-alias-label-tertiary,#9aa0a6);}
[data-dd-row]{display:flex;align-items:center;gap:10px;flex-wrap:wrap;}
[data-dd-grow]{flex:1;min-width:0;}
[data-dd-label]{font-size:13px;}
[data-dd-note]{font-size:11px;line-height:16px;color:var(--dsw-alias-label-tertiary,#9aa0a6);}
[data-dd-sw]{flex:none;width:38px;height:22px;border-radius:11px;border:0;cursor:pointer;position:relative;
  background:var(--dsw-alias-interactive-bg-hover,rgba(128,128,128,.35));transition:background .15s;padding:0;}
[data-dd-sw][data-on]{background:#3b82f6;}
[data-dd-sw] i{position:absolute;top:3px;left:3px;width:16px;height:16px;border-radius:50%;background:#fff;transition:left .15s;display:block;}
[data-dd-sw][data-on] i{left:19px;}
[data-dd-sw][disabled]{opacity:.45;cursor:default;}
[data-dd-sub]{margin-left:14px;padding-left:12px;border-left:2px solid var(--dsw-alias-bg-layer-3,rgba(255,255,255,.1));
  display:flex;flex-direction:column;gap:10px;}
[data-dd-input]{width:100%;box-sizing:border-box;padding:7px 9px;border-radius:8px;font-size:12px;
  border:1px solid var(--dsw-alias-bg-layer-3,rgba(255,255,255,.14));
  background:var(--dsw-alias-bg-layer-4,rgba(128,128,128,.12));color:inherit;font-family:inherit;}
[data-dd-input]:focus{outline:none;border-color:#3b82f6;}
[data-dd-num]{width:88px;text-align:center;}
[data-dd-btn]{padding:7px 12px;border-radius:8px;font-size:12px;cursor:pointer;font-family:inherit;white-space:nowrap;
  border:1px solid var(--dsw-alias-bg-layer-3,rgba(255,255,255,.16));
  background:var(--dsw-alias-bg-layer-4,rgba(128,128,128,.14));color:inherit;}
[data-dd-btn]:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(128,128,128,.24));}
[data-dd-btn][data-primary]{background:#3b82f6;border-color:#3b82f6;color:#fff;}
[data-dd-btn][disabled]{opacity:.5;cursor:default;}
[data-dd-msg]{font-size:11px;line-height:16px;padding:7px 9px;border-radius:8px;word-break:break-all;
  background:var(--dsw-alias-bg-layer-4,rgba(128,128,128,.12));}
[data-dd-msg][data-err]{color:#e5484d;}
[data-dd-msg][data-ok]{color:#30a46c;}
[data-dd-badge]{display:inline-block;font-size:10px;padding:2px 6px;border-radius:6px;
  background:var(--dsw-alias-bg-layer-4,rgba(128,128,128,.16));color:var(--dsw-alias-label-tertiary,#9aa0a6);}
[data-dd-pre]{white-space:pre-wrap;word-break:break-word;font-size:11px;line-height:17px;max-height:340px;overflow:auto;
  padding:10px;border-radius:8px;background:var(--dsw-alias-bg-layer-4,rgba(128,128,128,.1));margin:0;}
`

    // ── 小零件 ────────────────────────────────────────────────
    const Sw = ({ on, disabled, onChange }) => h('button', {
      'data-dd-sw': '', 'data-on': on ? '' : undefined, disabled,
      onClick: () => !disabled && onChange(!on),
    }, h('i'))

    const Row = ({ label, note, children }) => h('div', { 'data-dd-row': '' },
      h('div', { 'data-dd-grow': '' },
        h('div', { 'data-dd-label': '' }, label),
        note ? h('div', { 'data-dd-note': '' }, note) : null),
      children)

    const Num = ({ value, onChange, min = 0, max = 99, w }) => h('input', {
      'data-dd-input': '', 'data-dd-num': '', type: 'number', value,
      style: w ? { width: String(w) + 'px' } : undefined,
      min, max,
      onChange: (e) => {
        const v = Number(e.target.value)
        if (Number.isNaN(v)) return
        onChange(Math.max(min, Math.min(max, v)))
      },
    })

    const Txt = ({ value, placeholder, onChange, mono }) => h('input', {
      'data-dd-input': '', type: 'text', value: value ?? '', placeholder,
      style: mono ? { fontFamily: 'ui-monospace,Menlo,Consolas,monospace' } : undefined,
      onChange: (e) => onChange(e.target.value),
    })

    function Panel() {
      const [cfg, setCfg] = useState(null)
      const [st, setSt] = useState({})
      const [msg, setMsg] = useState({ text: '', kind: '' })
      const [busy, setBusy] = useState('')
      const [report, setReport] = useState(null)
      const [logTail, setLogTail] = useState(null)
      const [test, setTest] = useState(null)
      const [polling, setPolling] = useState(false)

      const say = (text, kind) => setMsg({ text, kind: kind || '' })

      const load = useCallback(async () => {
        try {
          const c = await jget('/config')
          setCfg(c.cfg)
          const s = await jget('/status')
          setSt(s)
        } catch (e) { say('读配置失败：' + e.message, 'err') }
      }, [])

      useEffect(() => { load() }, [load])

      const patch = useCallback(async (p) => {
        setCfg((c) => ({ ...(c || {}), ...p }))
        try {
          const r = await jpost('/config', p)
          if (r.cfg) setCfg(r.cfg)
        } catch (e) { say('保存失败：' + e.message, 'err'); load() }
      }, [load])

      const patchSrc = useCallback(async (k, v) => {
        const next = { ...(cfg?.sources || {}), [k]: v }
        await patch({ sources: next })
      }, [cfg, patch])

      // ── 登录：开窗口 → 轮询 ──
      const onLogin = async () => {
        setBusy('login')
        try {
          const r = await jpost('/login/start', {})
          say(r.hint || '浏览器窗口已打开', '')
          setPolling(true)
        } catch (e) { say('开登录窗口失败：' + e.message, 'err') } finally { setBusy('') }
      }

      useEffect(() => {
        if (!polling) return
        let n = 0
        const t = setInterval(async () => {
          n++
          if (n > 120) { setPolling(false); say('等太久了，刷新页面再试一次', 'err'); return }
          try {
            const r = await jget('/login/poll')
            if (r.state === 'ok') {
              setPolling(false)
              say('登录成功：' + (r.who || ''), 'ok')
              load()
            }
          } catch { /* 下一跳再试 */ }
        }, 2000)
        return () => clearInterval(t)
      }, [polling, load])

      // ── 动作 ──
      const onRun = async () => {
        setBusy('run')
        try { const r = await jpost('/run', {}); say(r.started ? '已开跑 —— 过几分钟回来看报告' : ('没跑起来：' + (r.error || '')), r.started ? 'ok' : 'err') }
        catch (e) { say(e.message, 'err') } finally { setBusy('') }
      }

      const onTest = async () => {
        setBusy('test'); setTest(null)
        try { setTest(await jget('/test')) } catch (e) { say('自检失败：' + e.message, 'err') } finally { setBusy('') }
      }

      const onReport = async () => {
        if (report !== null) { setReport(null); return }
        setBusy('report')
        try { const r = await jget('/report'); setReport(r.ok ? r.md : '（今天还没有报告）') }
        catch (e) { say(e.message, 'err') } finally { setBusy('') }
      }

      const onLog = async () => {
        if (logTail !== null) { setLogTail(null); return }
        try { const r = await jget('/log'); setLogTail(r.tail || '（空）') } catch (e) { say(e.message, 'err') }
      }

      if (!cfg) return h('div', { 'data-dd-page': '' }, h('div', { 'data-dd-note': '' }, '读配置中…'))

      return h('div', { 'data-dd-page': '' },

        /* ── 头 ── */
        h('div', { 'data-dd-row': '' },
          h('div', { 'data-dd-grow': '' },
            h('div', { 'data-dd-label': '' }, '刷抖音'),
            h('div', { 'data-dd-note': '' }, '每天替你刷一轮：搜、看画面、挑出值得的，写成日报。')),
          h('span', { 'data-dd-badge': '' }, 'v' + (st.version || '')),
          h('span', { 'data-dd-badge': '' }, st.loggedIn ? '已登录 ' + (st.who || '') : '未登录'),
          h('span', { 'data-dd-badge': '' }, st.peakNow ? '现在是高峰' : '现在是谷时')),

        msg.text ? h('div', { 'data-dd-msg': '', 'data-err': msg.kind === 'err' ? '' : undefined, 'data-ok': msg.kind === 'ok' ? '' : undefined }, msg.text) : null,

        /* ── 账号 ── */
        h('div', { 'data-dd-sec': '' },
          h('div', { 'data-dd-h': '' }, '账号'),
          h('div', { 'data-dd-row': '' },
            h('button', { 'data-dd-btn': '', 'data-primary': '', disabled: busy === 'login' || polling, onClick: onLogin },
              polling ? '等你扫码…' : '登录抖音'),
            h('div', { 'data-dd-note': '' }, st.loggedIn ? `已登录：${st.who}` : '点一下会开一个浏览器窗口，在里面扫码登录（登完自动变绿）')),
          h('div', { 'data-dd-note': '' }, '登录态存在插件自己的浏览器 profile 里，跟你现在用的浏览器互不干扰，重启也在。')),

        /* ── 刷什么 ── */
        h('div', { 'data-dd-sec': '' },
          h('div', { 'data-dd-h': '' }, '刷什么'),
          h(Row, { label: '关键词搜索', note: '按你填的词搜最近的作品' }, h(Sw, { on: !!cfg.sources?.search, onChange: (v) => patchSrc('search', v) })),
          cfg.sources?.search ? h('div', { 'data-dd-sub': '' },
            h('div', { 'data-dd-note': '' }, '留空 = 用章程里默认的（AI / 编程 / 效率工具 / 摄影 / 健身）'),
            h(Txt, { value: (cfg.keywords || []).join('、'), placeholder: 'AI、编程、摄影', onChange: (v) => patch({ keywords: v.split(/[、,，\s]+/).filter(Boolean) }) })) : null,
          h(Row, { label: '关注列表', note: '你关注的人最近发了什么' }, h(Sw, { on: !!cfg.sources?.following, onChange: (v) => patchSrc('following', v) })),
          h(Row, { label: '热榜', note: '看今天什么在火' }, h(Sw, { on: !!cfg.sources?.hot, onChange: (v) => patchSrc('hot', v) })),
          h(Row, { label: '指定博主', note: '填主页链接，逐个看新作品' }, h(Sw, { on: !!cfg.sources?.users, onChange: (v) => patchSrc('users', v) })),
          cfg.sources?.users ? h('div', { 'data-dd-sub': '' },
            h(Txt, { value: (cfg.userUrls || []).join(' '), placeholder: 'https://www.douyin.com/user/MS4wLjABAAAA... （空格分隔）', onChange: (v) => patch({ userUrls: v.split(/\s+/).filter(Boolean) }) })) : null,
          h(Row, { label: '推荐流', note: '刷抖音推给你的内容（默认关）' }, h(Sw, { on: !!cfg.sources?.feed, onChange: (v) => patchSrc('feed', v) }))),

        /* ── 怎么判 ── */
        h('div', { 'data-dd-sec': '' },
          h('div', { 'data-dd-h': '' }, '怎么判'),
          h(Row, { label: '每天最多挑几条', note: '挑满就收工 —— 宁缺毋滥' }, h(Num, { value: cfg.perDay, min: 1, max: 20, onChange: (v) => patch({ perDay: v }) })),
          h(Row, { label: '每条截几帧', note: '截帧要真播一遍视频，越多越慢越花钱' }, h(Num, { value: cfg.framesPerVideo, min: 1, max: 6, onChange: (v) => patch({ framesPerVideo: v }) })),
          h(Row, { label: '画面文字（OCR）', note: 'Windows 自带，零依赖。抖音没字幕，画面里的字常常就是全部信息' },
            h(Sw, { on: !!cfg.useOcr, onChange: (v) => patch({ useOcr: v }) })),
          h(Row, { label: '画面理解（视觉模型）', note: '⚠️ 要花钱：填一个多模态接口让它"看图说话"。默认模型 deepseek-flash 看不了图' },
            h(Sw, { on: !!cfg.useVision, onChange: (v) => patch({ useVision: v }) })),
          cfg.useVision ? h('div', { 'data-dd-sub': '' },
            h(Txt, { value: cfg.visionApiBase, placeholder: 'https://api.xxx.com/v1', onChange: (v) => patch({ visionApiBase: v }), mono: true }),
            h(Txt, { value: cfg.visionApiKey, placeholder: 'sk-...', onChange: (v) => patch({ visionApiKey: v }), mono: true }),
            h(Txt, { value: cfg.visionModel, placeholder: '模型名，如 gpt-4o-mini / qwen-vl-max', onChange: (v) => patch({ visionModel: v }), mono: true }),
            h('div', { 'data-dd-note': '' }, '按 OpenAI 兼容的 /chat/completions 调；三样都填才会真用。')) : null),

        /* ── 产出 ── */
        h('div', { 'data-dd-sec': '' },
          h('div', { 'data-dd-h': '' }, '产出'),
          h(Row, { label: '日报', note: 'full=完整 / brief=每条一两行 / off=不写' },
            h('select', {
              'data-dd-input': '', style: { width: '120px' }, value: cfg.reportLevel || 'full',
              onChange: (e) => patch({ reportLevel: e.target.value }),
            }, h('option', { value: 'full' }, '完整'), h('option', { value: 'brief' }, '简版'), h('option', { value: 'off' }, '不写'))),
          h(Row, { label: '自动收藏', note: '⚠️ 会动你的账号：挑中的自动加收藏（默认关）' },
            h(Sw, { on: !!cfg.favOn, onChange: (v) => patch({ favOn: v }) })),
          h(Row, { label: '评论并 @ 你', note: '⚠️ 拿你的号公开说话 —— 默认关，要你自己开' },
            h(Sw, { on: !!cfg.autoComment, onChange: (v) => patch({ autoComment: v }) })),
          cfg.autoComment ? h('div', { 'data-dd-sub': '' },
            h(Row, { label: '要 @ 谁（抖音昵称）' }, h(Txt, { value: cfg.mentionName, placeholder: '留空 = 不发', onChange: (v) => patch({ mentionName: v }) })),
            h(Row, { label: '每轮最多发几条' }, h(Num, { value: cfg.commentPerRound, min: 1, max: 5, onChange: (v) => patch({ commentPerRound: v }) }))) : null),

        /* ── 什么时候跑 ── */
        h('div', { 'data-dd-sec': '' },
          h('div', { 'data-dd-h': '' }, '什么时候跑'),
          h(Row, { label: '谷时自动跑', note: '工作日 9–12 / 14–18 是高峰，其余（含整个周末）都便宜' },
            h(Sw, { on: !!cfg.peakValley, onChange: (v) => patch({ peakValley: v }) })),
          cfg.peakValley ? h('div', { 'data-dd-sub': '' },
            h(Row, { label: '中午谷时（12–14 点）' }, h(Sw, { on: !!cfg.noon, onChange: (v) => patch({ noon: v }) })),
            h(Row, { label: '晚上谷时（18 点–次日 9 点）' }, h(Sw, { on: !!cfg.night, onChange: (v) => patch({ night: v }) }))) : null,
          h(Row, { label: '每日固定时间', note: '留空 = 不启用；填 08:30 这种' },
            h(Txt, { value: cfg.dailyAt, placeholder: 'HH:mm', onChange: (v) => patch({ dailyAt: v }) })),
          h(Row, { label: '开 dsh 时补跑', note: '今天还没跑过、且现在是谷时 ⇒ 起来 25 秒后自动补一轮' },
            h(Sw, { on: !!cfg.onStart, onChange: (v) => patch({ onStart: v }) })),
          h('div', { 'data-dd-row': '' },
            h('button', { 'data-dd-btn': '', 'data-primary': '', disabled: busy === 'run', onClick: onRun }, '现在跑一轮'),
            h('div', { 'data-dd-note': '' }, '不等定时，立刻刷一轮（桌面版上这条最稳）'))),

        /* ── 自检 ── */
        h('div', { 'data-dd-sec': '' },
          h('div', { 'data-dd-h': '' }, '自检'),
          h('div', { 'data-dd-row': '' },
            h('button', { 'data-dd-btn': '', disabled: busy === 'test', onClick: onTest }, '测一下'),
            h('button', { 'data-dd-btn': '', onClick: onReport }, report !== null ? '收起报告' : '看今天的报告'),
            h('button', { 'data-dd-btn': '', onClick: onLog }, logTail !== null ? '收起日志' : '看日志')),
          test ? h('div', { 'data-dd-msg': '', 'data-ok': test.ok ? '' : undefined, 'data-err': test.ok ? undefined : '' },
            (test.steps || []).map((s) => `${s.ok ? '✓' : '✗'} ${s.name}：${s.msg}`).join('　') || test.error || '') : null,
          report !== null ? h('pre', { 'data-dd-pre': '' }, report) : null,
          logTail !== null ? h('pre', { 'data-dd-pre': '' }, logTail) : null,
          h('div', { 'data-dd-note': '' }, `家目录：${st.home || ''}`),
          h('div', { 'data-dd-note': '' }, `今天的报告：${st.report || '（还没有）'} · 已挑 ${st.pickedToday || 0}/${st.perDay || 0} 条`)),
      )
    }

    return {
      inject: ['slots'],
      apply(ctx) {
        const style = document.createElement('style')
        style.setAttribute('data-plugin-css', 'dsh-douyin-scroll')
        style.textContent = CSS
        document.head.appendChild(style)
        ctx.effect(() => () => style.remove(), 'dsh-douyin-scroll: 设置页样式')

        const slots = (typeof ctx.get === 'function' ? ctx.get('slots') : undefined) || ctx.slots
        if (!slots) return
        slots.inject('settings.section', () => slots.register(
          { name: 'settings.section', id: 'douyin-scroll', order: 31, label: '刷抖音' },
          () => h(Panel),
        ))
      },
    }
  },
})
